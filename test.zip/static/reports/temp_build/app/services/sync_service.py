import httpx
import os
import shutil
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy import text
from app.core.config import settings
from loguru import logger
import datetime

class SyncService:
    @staticmethod
    async def get_remote_data():
        remote_url = "mysql+aiomysql://traccar:traccar12344321@202.141.246.12/traccar"
        remote_engine = create_async_engine(remote_url)
        
        users = []
        devices = []
        user_devices = []
        servers = []

        try:
            async with remote_engine.connect() as conn:
                await conn.execute(text("SET SESSION sql_mode = '';"))
                
                users_res = await conn.execute(text("SELECT * FROM tc_users"))
                users = [dict(row._mapping) for row in users_res]
                
                devices_res = await conn.execute(text("SELECT * FROM tc_devices"))
                devices = [dict(row._mapping) for row in devices_res]
                
                ud_res = await conn.execute(text("SELECT * FROM tc_user_device"))
                user_devices = [dict(row._mapping) for row in ud_res]

                server_res = await conn.execute(text("SELECT * FROM tc_servers"))
                servers = [dict(row._mapping) for row in server_res]
                
            return users, devices, user_devices, servers
        finally:
            await remote_engine.dispose()

    @staticmethod
    def sanitize_val(v):
        if v == '0000-00-00 00:00:00' or v == '0000-00-00':
            return None
        return v

    @staticmethod
    async def start_sync(db: AsyncSession):
        try:
            logger.info("Syncing FULL Server Config (including tc_servers)...")
            await db.execute(text("SET FOREIGN_KEY_CHECKS = 0;"))
            await db.execute(text("SET SESSION sql_mode = '';"))
            
            users, devices, user_devices, servers = await SyncService.get_remote_data()
            
            async def get_cols(table):
                res = await db.execute(text(f"DESC {table}"))
                return [row[0] for row in res.fetchall()]

            l_u_cols = await get_cols("tc_users")
            l_d_cols = await get_cols("tc_devices")
            l_s_cols = await get_cols("tc_servers")

            # Sync Servers Fix
            for s in servers:
                data = {k: SyncService.sanitize_val(v) for k, v in s.items() if k in l_s_cols}
                cols = ", ".join([f"`{k}`" for k in data.keys()])
                places = ", ".join([f":{k}" for k in data.keys()])
                updates = ", ".join([f"`{k}`=VALUES(`{k}`)" for k in data.keys() if k != "id"])
                await db.execute(text(f"INSERT INTO tc_servers ({cols}) VALUES ({places}) ON DUPLICATE KEY UPDATE {updates}"), data)

            # Sync Users
            for u in users:
                data = {k: SyncService.sanitize_val(v) for k, v in u.items() if k in l_u_cols}
                cols = ", ".join([f"`{k}`" for k in data.keys()])
                places = ", ".join([f":{k}" for k in data.keys()])
                updates = ", ".join([f"`{k}`=VALUES(`{k}`)" for k in data.keys() if k != "id"])
                await db.execute(text(f"INSERT INTO tc_users ({cols}) VALUES ({places}) ON DUPLICATE KEY UPDATE {updates}"), data)

            # Sync Devices
            for d in devices:
                data = {k: SyncService.sanitize_val(v) for k, v in d.items() if k in l_d_cols}
                cols = ", ".join([f"`{k}`" for k in data.keys()])
                places = ", ".join([f":{k}" for k in data.keys()])
                updates = ", ".join([f"`{k}`=VALUES(`{k}`)" for k in data.keys() if k != "id"])
                await db.execute(text(f"INSERT INTO tc_devices ({cols}) VALUES ({places}) ON DUPLICATE KEY UPDATE {updates}"), data)

            # Permissions
            await db.execute(text("DELETE FROM tc_user_device"))
            for ud in user_devices:
                await db.execute(text("INSERT INTO tc_user_device (userid, deviceid) VALUES (:userid, :deviceid)"), ud)

            await db.execute(text("SET FOREIGN_KEY_CHECKS = 1;"))
            await db.commit()
            logger.info("SERVER SYNC SUCCESSFUL.")
            return {"status": "success", "users": len(users), "devices": len(devices)}

        except Exception as e:
            logger.error(f"SYNC ERROR: {e}")
            await db.execute(text("SET FOREIGN_KEY_CHECKS = 1;"))
            await db.rollback()
            raise e

    @staticmethod
    async def deploy_to_prod():
        """
        Manually pushes the current codebase (PC14) to PC12 across LAN.
        If LAN fails, creates a zip for direct download.
        """
        source_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        target_path = settings.PROD_NETWORK_PATH

        IGNORE_LIST = ['.env', 'venv', '.venv', '__pycache__', '.git', 'qdrant_storage', 'logs', 'sync_output.txt']

        def ignore_files(dir_path, filenames):
            return [f for f in filenames if f in IGNORE_LIST or f.endswith('.pyc')]

        # Check if HTTP Push
        if target_path and target_path.startswith('http'):
            try:
                import httpx
                logger.info(f"DEPLOYING FROM {source_dir} VIA HTTP TO {target_path}")
                
                # Create Zip
                temp_dir = os.path.join(source_dir, 'temp_build')
                if os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir)
                shutil.copytree(source_dir, temp_dir, ignore=ignore_files, dirs_exist_ok=True)
                zip_path = os.path.join(source_dir, 'http_deploy')
                shutil.make_archive(zip_path, 'zip', temp_dir)
                shutil.rmtree(temp_dir)
                
                # Send HTTP POST
                with open(zip_path + ".zip", "rb") as f:
                    r = httpx.post(target_path, files={"file": f}, timeout=30.0)
                
                os.remove(zip_path + ".zip")
                
                if r.status_code == 200:
                    return {"status": "success", "message": "Codebase successfully deployed via HTTP automatically!"}
                else:
                    logger.error(f"HTTP DEPLOYMENT HTTP ERROR: {r.text}")
                    # Fallthrough to standard ZIP download
            except Exception as e:
                logger.error(f"HTTP DEPLOYMENT FAILED: {e}")
                # Fallthrough to standard ZIP download
        
        # Try LAN Sync
        elif target_path and os.path.exists(target_path):
            try:
                logger.info(f"DEPLOYING FROM {source_dir} TO {target_path}")
                shutil.copytree(source_dir, target_path, ignore=ignore_files, dirs_exist_ok=True)
                return {"status": "success", "message": "Codebase successfully synchronized directly to PC 12 via LAN."}
            except Exception as e:
                logger.error(f"LAN DEPLOYMENT FAILED: {e}")
                # Fallthrough to ZIP
        
        # Fallback: Create ZIP for download
        try:
            reports_dir = os.path.join(source_dir, 'static', 'reports')
            os.makedirs(reports_dir, exist_ok=True)
            zip_path = os.path.join(reports_dir, 'FleetAI_PC12_Production')
            
            # Temporary copy to exclude files before zipping
            temp_dir = os.path.join(source_dir, 'static', 'reports', 'temp_build')
            if os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
            shutil.copytree(source_dir, temp_dir, ignore=ignore_files, dirs_exist_ok=True)
            
            shutil.make_archive(zip_path, 'zip', temp_dir)
            shutil.rmtree(temp_dir)
            
            return {
                "status": "success", 
                "message": "LAN unavailable. Generated Production ZIP for direct download.",
                "download_url": "/static/reports/FleetAI_PC12_Production.zip"
            }
        except Exception as e:
            logger.error(f"ZIP GENERATION FAILED: {e}")
            raise Exception(f"Deployment failed. Could not sync to LAN or generate ZIP: {str(e)}")
