from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.api.auth import get_current_user
from app.services.sync_service import SyncService
from typing import Dict, Any

router = APIRouter()

@router.post("/start")
async def start_sync_endpoint(
    db: AsyncSession = Depends(get_db),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Triggers a manual sync from PC12 to current instance.
    Only SUPERADMIN can trigger sync.
    """
    if current_user.get("role") != "SUPERADMIN":
        raise HTTPException(status_code=403, detail="Only administrators can trigger full data sync.")
    
    try:
        result = await SyncService.start_sync(db)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Sync failed: {str(e)}")

@router.post("/deploy")
async def deploy_to_prod_endpoint(
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Triggers code deployment from PC14 to PC12.
    Only SUPERADMIN can trigger deployment.
    """
    if current_user.get("role") != "SUPERADMIN":
        raise HTTPException(status_code=403, detail="Only administrators can trigger production deployment.")
    
    try:
        result = await SyncService.deploy_to_prod()
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")

from fastapi import UploadFile, File
import zipfile
import os

@router.post("/receive")
async def receive_sync_payload(file: UploadFile = File(...)):
    """Receives updated codebase from dev PC via HTTP and deploys it."""
    try:
        project_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        temp_zip = f"{project_dir}/temp_deploy.zip"
        
        with open(temp_zip, "wb") as f:
            f.write(await file.read())
            
        with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
            zip_ref.extractall(project_dir)
            
        os.remove(temp_zip)
        return {"status": "success", "message": "Production updated successfully via HTTP API."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
