import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from app.services.sync_service import SyncService
from app.core.config import settings
import sys
import os

# Add current dir to path for imports
sys.path.append(os.getcwd())

async def verify_sync():
    # Use local MySQL URL
    url = "mysql+aiomysql://traccar:traccar12344321@localhost/traccar"
    engine = create_async_engine(url)
    SessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    
    async with SessionLocal() as db:
        print("Starting Manual Sync Verification...")
        try:
            result = await SyncService.start_sync(db)
            print(f"Sync Results: {result}")
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"Sync Failed: {e}")
    
    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(verify_sync())
